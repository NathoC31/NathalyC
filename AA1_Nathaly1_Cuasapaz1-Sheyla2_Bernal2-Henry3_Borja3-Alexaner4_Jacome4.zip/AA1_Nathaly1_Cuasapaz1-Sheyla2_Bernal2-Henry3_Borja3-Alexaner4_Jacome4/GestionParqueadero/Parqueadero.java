package GestionParqueadero;

import java.util.ArrayList;

public class Parqueadero {
    private ArrayList<Vehiculo> vehiculos;

    public Parqueadero() {
        this.vehiculos = new ArrayList<>();
    }

    public void registrarVehiculo(String placa, String propietario, String tipoVehiculo, long horaEntrada) {
        Vehiculo vehiculo = new Vehiculo(placa, propietario, tipoVehiculo, horaEntrada);
        vehiculos.add(vehiculo);
        System.out.println("Vehículo registrado: " + vehiculo);
    }

    public void registrarSalida(int idVehiculo, long horaSalida) {
        Vehiculo vehiculo = buscarVehiculo(idVehiculo);
        if (vehiculo != null && vehiculo.isEstado()) {
            vehiculo.setHoraSalida(horaSalida);
            vehiculo.setEstado(false);
            double pago = vehiculo.calcularPago();
            System.out.println("El vehículo con ID " + idVehiculo + " ha salido. Total a pagar: $" + pago);
        } else {
            System.out.println("Vehículo no encontrado o ya salió.");
        }
    }
    
    public void mostrarVehiculosDentro() {
        System.out.println("\n--- Vehículos dentro del parqueadero ---");
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.isEstado()) {
                System.out.println(vehiculo);
            }
        }
    }

    private Vehiculo buscarVehiculo(int id) {
        for (Vehiculo vehiculo : vehiculos) {
            if (vehiculo.getId() == id) {
                return vehiculo;
            }
        }
        return null;
    }
}
