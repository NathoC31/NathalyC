/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package gp;

import gp.Vista.Vista;
/**
 * UNIVERSIDAD DE LAS FUERZAS ARMADAS - ESPE
 * DEPARTAMENTO DE CIENCIAS DE LA COMPUTACIÓN
 * ASIGNATURA: PROGRAMACIÓN ORIENTADO A OBJETOS
 * DOCENTE: MGRT. JARAMILLO L.
 * TEMA: TRABAJO PRÁCTICO
 * INTEGRANTES: 
 *  GRANADA DAVID
 * 
 */
public class GP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Vista vista = new Vista();
        vista.setVisible(true);
    }
    
}
