/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gp.Modelo;
/**
 * UNIVERSIDAD DE LAS FUERZAS ARMADAS - ESPE
 * DEPARTAMENTO DE CIENCIAS DE LA COMPUTACIÓN
 * ASIGNATURA: PROGRAMACIÓN ORIENTADO A OBJETOS
 * DOCENTE: MGRT. JARAMILLO L.
 * TEMA: TRABAJO PRÁCTICO
 * INTEGRANTES: 
 *  GRANADA DAVID
 * 
 */

public class Productos{


}
